<div class="tab-box-item" data-tab-box-title="<?php echo $title; ?>"<?php echo $css_class; ?> id="<?php echo $tab_id; ?>">
	<?php echo do_shortcode( $content_html ); ?>
</div>