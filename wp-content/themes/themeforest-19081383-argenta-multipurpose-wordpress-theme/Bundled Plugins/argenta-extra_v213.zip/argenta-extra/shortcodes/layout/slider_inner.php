<div class="slider-wrap">
	<?php echo do_shortcode( $content_html ); ?>
</div>