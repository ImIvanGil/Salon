	<ul class="list-box-icon contact-module<?php if ( $list_items_type == 'with_border' ) { echo ' list-box-border-items-offset'; } ?><?php echo $css_class; ?>">
	
		<?php echo do_shortcode( $content ); ?>

	</ul>