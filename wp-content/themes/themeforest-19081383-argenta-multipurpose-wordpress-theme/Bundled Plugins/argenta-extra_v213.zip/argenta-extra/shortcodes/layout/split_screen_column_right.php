<div class="ms-right">
	<?php echo do_shortcode( $content ); ?>
</div>