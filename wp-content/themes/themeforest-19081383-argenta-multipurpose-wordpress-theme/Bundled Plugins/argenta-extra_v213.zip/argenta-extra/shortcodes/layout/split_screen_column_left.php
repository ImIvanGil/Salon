<div class="ms-left">
	<?php echo do_shortcode( $content ); ?>
</div>