<?php if ( \Argenta\Settings::get( 'page_preloader', 'global' ) || \Argenta\Settings::get( 'page_preloader', 'global' ) === NULL ) : ?>

<div class="page-preloader" id="page-preloader">
	<div class="loader"></div>
</div>

<?php endif; ?>